import httpx
import asyncio
from pyrogram import Client, filters
from FUNC.usersdb_func import *
from TOOLS.check_all_func import *
import openai

# OpenAI API Key
openai_api_key = "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"
openai_client = openai.OpenAI(api_key=openai_api_key)


# Fetch GPT response
async def fetch_response(prompt):
    data = {
        "model": "gpt-3.5-turbo",
        "messages": [{"role": "user", "content": prompt}]
    }

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {openai_api_key}"
    }

    async with httpx.AsyncClient(timeout=30) as client:
        try:
            response = await client.post(
                "https://api.openai.com/v1/chat/completions",
                json=data,
                headers=headers
            )
            response.raise_for_status()
            completion = response.json()
            if 'choices' not in completion or len(completion['choices']) == 0:
                raise ValueError("No response choices found.")
            return completion["choices"][0]["message"]["content"]
        except httpx.ReadTimeout:
            raise TimeoutError("The OpenAI API request timed out.")
        except Exception as e:
            raise RuntimeError(f"API Error: {e}")


# GPT Command Handler
@Client.on_message(filters.command("gpt", [".", "/"]))
async def cmd_gpt(client, message):
    try:
        checkall = await check_all_thing(client, message)
        if not checkall[0]:
            return

        role = checkall[1]

        # Extract prompt
        if message.reply_to_message and message.reply_to_message.text:
            prompt = message.reply_to_message.text
        else:
            try:
                prompt = message.text.split(" ", 1)[1]
            except IndexError:
                await message.reply_text(
                    "<b>Invalid Prompt ⚠️</b>\n\nMessage: No valid prompt provided."
                )
                return

        # Indicate processing
        processing_message = await message.reply_text("⌛️ Answering...")

        # Retry logic for API call
        max_retries = 3
        for attempt in range(max_retries):
            try:
                response = await fetch_response(prompt)
                break
            except TimeoutError:
                await asyncio.sleep(2 ** attempt)  # Exponential backoff
            except Exception as e:
                import traceback
                await error_log(traceback.format_exc())
                await processing_message.edit_text(
                    "⚠️ Failed to generate a response. Please try again later."
                )
                return
        else:
            await processing_message.edit_text(
                "⚠️ Timeout: The request took too long to process."
            )
            return

        # Send response
        await processing_message.edit_text(f"<b>{response}</b>")

    except Exception as e:
        import traceback
        await error_log(traceback.format_exc())
        await message.reply_text(
            "⚠️ An unexpected error occurred. Please try again later."
        )
